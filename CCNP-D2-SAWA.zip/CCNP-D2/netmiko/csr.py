from netmiko import ConnectHandler as con

## DEVICE INFO
ph =  {
    'device_type': 'cisco_ios',
    'host': '192.168.102.11',
    'username': 'admin',
    'password': 'pass',
    'secret': 'pass',
    'port': 22
}

## COMMANDS
config = [
    'interface loopback 1',
    'ip add 1.1.1.1 255.255.255.255',
    'description  CONFIGURED-VIA-PYTHON',
    'no shutdown',
    'end'
]

## CONNECT
cli = con(**ph)
siib = cli.send_command('show ip int br')
print(siib)


cli.send_config_set(config)
siib = cli.send_command('show ip int br')
print(siib)
cli.disconnect()
