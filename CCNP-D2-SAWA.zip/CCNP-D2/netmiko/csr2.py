from netmiko import ConnectHandler as con
from pprint import pp as print
import json

def addloop(name,type,host,user,password,port,secret,configs,store=False):
    info = {
        'device_type': type,
        'host': host,
        'username': user,
        'password': password,
        'secret': secret,
        'port': port
    }
    
    cm = [
        f'interface {configs['type']} {configs['id']}',
        f'ip add {configs['ipv4']} {configs['mask']}',
        f'description {configs['desc']}'
    ]
    
    if configs['shut'] == False:
        cm.append('shutdown')
        
    
    cli = con(**info)
    cli.enable()
    siib = cli.send_command('show ip int br')
    output = cli.send_config_set(cm)
    
    ftpserver = '192.168.102.1'
    filename = f'{name}' + '-Configs'
    
    ftp = cli.send_command_timing('copy run ftp:')
    if 'remote host' in ftp:
        ftp = cli.send_command_timing(ftpserver)
        if 'filename' in ftp:
            ftp = cli.send_command_timing(filename)
    
    cli.disconnect()
    
    print(output)
    
    if store:
        with open('siib.txt', 'a') as file:
            file.write(siib)
            file.write('\n\n' + '-'*20 + '\n\n')


if __name__ == '__main__':
    
    with open('csr2.json', 'r') as filejs:
        filepy = json.load(filejs)
    
    # ph = filepy['devices'][0]
    # addloop(**ph)
    
    for i in filepy['devices']:
        addloop(**i)
        






















































#     print(info)



# if __name__ == '__main__':

#     with open('csr2.json', 'r') as filejs:
#         filepy = json.load(filejs)
#     #print(filepy['devices'][0])
#     # ph = ['devices'][0]

#     # addloop(**ph)

#     for i in filepy['devices']:
#         addloop(**i)







































































# from netmiko import ConnectHandler as con
# from pprint import pp as print
# import json

# def addloop(name,type,host,user,password,port,secret):
#     info = {
#         'device_type': type,
#         'host': host,
#         'username': user,
#         'password': password,
#         'secret': secret,
#         'port': port
#     }
    
#     print(info)



# if __name__ == '__main__':
    
#     with open('csr2.json', 'r') as filejs:
#         filepy = json.load(filejs)
    
#     # ph = filepy['devices'][0]
#     # addloop(**ph)
    
#     for i in filepy['devices']:
#         print(i)