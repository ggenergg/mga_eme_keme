# py_dictionary = {
#     'key_string': 'value_string',
#     'key_int': 1,
#     'key_float': 1.0,
#     'key_boolean': True,
#     'key_list': [True, 2, 3.0, '5'],
#     'key_dictionary': {
#         'nested' : [
#             'I\'m',
#             'nested',
#             'data'
#         ]
#     }
# }

from json import load
from pprint import pp as print

with open('ex1.json','r') as filejs:
    filepy = load(filejs)
    #print (filepy['key_list'][0])

    # ex1 = filepy['key_list'][2]
    # print(ex1)

    ex2 = filepy['key_dictionary']['nested'][2]
    print(ex2)